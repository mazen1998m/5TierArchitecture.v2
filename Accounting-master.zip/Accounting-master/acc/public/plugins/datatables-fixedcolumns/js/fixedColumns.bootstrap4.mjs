/*! Bootstrap 4 integration for DataTables' FixedColumns
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-bs4';
import 'datatables.net-fixedcolumns';




export default DataTable;
