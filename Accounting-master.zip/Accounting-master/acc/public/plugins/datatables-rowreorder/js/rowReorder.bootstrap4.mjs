/*! Bootstrap 4 styling wrapper for RowReorder
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-bs4';
import 'datatables.net-rowreorder';




export default DataTable;
