/*! Bootstrap 4 styling wrapper for Scroller
 * © SpryMedia Ltd - datatables.net/license
 */

import $ from 'jquery';
import DataTable from 'datatables.net-bs4';
import Scroller from 'datatables.net-scroller';




export default DataTable;
